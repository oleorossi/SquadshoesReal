# Squad Shoes — Sistema de Gestão Industrial

## Visão Geral

**Squad Shoes** é um sistema de gestão industrial (ERP/MES) para indústria de **calçados femininos**. O software gerencia o chão-de-fábrica: ordens de produção, linhas, estoque de matéria-prima, controle de qualidade, expedição e indicadores operacionais.

> **Importante:** este NÃO é um e-commerce. É uma ferramenta interna usada por gerentes de planta, líderes de linha, operadores, controle de qualidade e PCP.

### Produto
- **Web app desktop-first** — uso intensivo em escritórios de planta e PCP
- **Tablets em chão-de-fábrica** — operadores apontam produção, registram defeitos, conferem lotes
- **Mobile (consultivo)** — gestores acompanham KPIs e alertas remotamente

### Público / Personas
- **Gerente de Planta** — visão geral, KPIs, alertas, prazos
- **PCP / Planejador** — cria e prioriza ordens de produção (OPs)
- **Líder de linha** — acompanha sua linha em tempo real, registra paradas
- **Operador** — apontamento por etapa (corte, costura, montagem, acabamento, embalagem)
- **Controle de qualidade** — registra defeitos, libera lotes
- **Almoxarifado** — recebimento, baixa de matéria-prima, inventário

### Materiais de origem
- Site marketing: `https://squadshoes.lovable.app`
- Tokens Tailwind (HSL CSS vars) extraídos de `tailwind.config.ts` enviado pelo usuário
- Logo: `assets/logo-squad-shoes.jpg`

---

## FUNDAMENTOS DE CONTEÚDO

**Idioma:** Português do Brasil em toda a UI. Nunca misturar inglês.

**Tom:** Direto, técnico, operacional. Sem marketing. Pessoas tomam decisões rápidas com este software — copy precisa ser curta e clara.

**Características de voz:**
- Use o vocabulário real da fábrica: **OP** (ordem de produção), **lote**, **par**, **numeração**, **fôrma**, **cabedal**, **sola**, **palmilha**, **forro**, **PCP**, **apontamento**, **refugo**, **retrabalho**, **OEE**
- Sentence case em rótulos e títulos. CAPS apenas para etapas (`CORTE`, `COSTURA`) e siglas
- Números sempre em algarismos: "420 pares", "3 OPs"
- Datas em formato BR: `30/04/2026 · 18:00` (ou relativas: "há 12 min", "em 2 dias")
- Quantidades de calçado em **pares**, não unidades
- Prazos: usar "vence em" / "atrasada" / "no prazo" — não "due"
- Sem emoji. Sem exclamação. Sem adjetivos de marketing.

**Exemplos:**
- ✅ "OP-2847 · 420 pares · vence hoje 18:00"
- ✅ "Linha B1 pausada — cola fora da temperatura"
- ✅ "Estoque de couro caramelo abaixo do ponto de pedido"
- ❌ "Awesome new order!" / "Check out the dashboard"
- ❌ "Pedido criado com sucesso! 🎉"

---

## FUNDAMENTOS VISUAIS

### Cores (HSL — alinhadas ao Tailwind config)

Sistema de design **HSL com CSS variables** (padrão shadcn/ui). Suporta light + dark mode via `.dark` no html.

**Tokens semânticos** (não usar cores cruas — sempre referenciar a variável):

| Token | Light | Dark | Uso |
|---|---|---|---|
| `--background` | `0 0% 100%` | `240 6% 10%` | fundo principal |
| `--foreground` | `240 10% 4%` | `0 0% 98%` | texto principal |
| `--card` | `0 0% 100%` | `240 6% 12%` | cards, painéis |
| `--muted` | `240 5% 96%` | `240 5% 16%` | seções secundárias |
| `--muted-foreground` | `240 4% 46%` | `240 5% 65%` | texto secundário |
| `--border` | `240 6% 90%` | `240 5% 20%` | bordas |
| `--primary` | `240 10% 4%` | `0 0% 98%` | botões primários, ações |
| `--accent` | `73 100% 50%` | `73 100% 50%` | **lime `#C8FF00`** — destaques pontuais |
| `--success` | `158 64% 40%` | `158 60% 45%` | OP em produção, estoque ok |
| `--warning` | `38 92% 50%` | `38 90% 55%` | pausa, estoque baixo |
| `--destructive` | `0 84% 60%` | `0 70% 55%` | bloqueio, defeito, falta |
| `--sidebar-background` | `240 8% 8%` | `240 8% 6%` | sidebar (sempre escura) |

**Diretrizes:**
- Lime `#C8FF00` é o accent da marca — use APENAS em momentos-chave: estado ativo da nav, KPI principal, indicador "ao vivo", botão primário de ação destrutiva (ex.: "Iniciar OP")
- Status sempre via cores semânticas (success/warning/destructive), nunca cores cruas
- Sidebar é **sempre escura** (mesmo em light mode) — mantém ancoragem visual em uso prolongado

### Tipografia

- **Display / UI:** **Plus Jakarta Sans** (300, 400, 500, 600, 700, 800)
- **Mono / dados:** **JetBrains Mono** (400, 500, 700) — para números, códigos (SKU, OP, lote), timestamps

```html
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500;700&display=swap" rel="stylesheet">
```

**Escala:**

| Nome | Tamanho | Peso | Uso |
|---|---|---|---|
| Display | 32px / -0.02em | 700 | título de página dashboard |
| H1 | 22px / -0.01em | 700 | título de seção principal |
| H2 | 18px | 700 | título de painel/card |
| H3 | 14px | 700 | subtítulos |
| Body | 13px | 500 | texto padrão de UI |
| Small | 12px | 500 | meta, timestamps, hints |
| Micro | 10–11px / +0.12em | 700 | labels uppercase, etapas |
| Numeric XL | 28–32px mono | 700 | KPIs |
| Numeric | 13–14px mono | 700 | quantidades, OPs, SKUs |

### Espaçamento & Layout

- Base 4px. Múltiplos de 4 (4, 8, 12, 16, 20, 24, 28, 32, 48)
- **Container:** centrado, padding 2rem, max-width 1400px (`2xl`)
- **Sidebar:** 240px expandida / 64px colapsada — sempre fixa
- **Topbar:** 64px de altura, sticky
- **Densidade:** UI densa — este é um software de trabalho. Linhas de tabela 36–40px, padding de card 16–18px

### Border-radius

Configurável via `--radius` (padrão `0.5rem` = 8px):
- `sm` = 4px (chips, pills, inputs)
- `md` = 6px (botões, badges)
- `lg` = 8px (cards, painéis, modais)

### Sombras & Elevação

- Card padrão: borda 1px, sem sombra (depende de borda neutra)
- Hover de linha de tabela: `bg-muted/50`
- Dropdown / popover: `0 8px 24px hsl(240 6% 10% / 0.12)`
- Modal: `0 24px 64px hsl(240 6% 10% / 0.28)` + overlay `bg-black/50`
- **Sem** sombras coloridas, sem inner-shadow, sem borda esquerda colorida em cards

### Animação & Movimento

- Transições padrão: `140ms ease-out` (interações), `220ms` (drawers/sidebar)
- `pulse-slow` (2s) — indicador "ao vivo" de linha em produção
- `slide-in` (0.3s) — toasts, drawers
- Sem bounce, sem spring. Movimento limpo, técnico.

### Iconografia

**Lucide Icons** via CDN — alinhado ao stroke 2px geométrico. Stroke uniforme, tamanho 14–16px em UI, 18–20px em KPIs.

```html
<script src="https://unpkg.com/lucide@latest/dist/umd/lucide.min.js"></script>
<i data-lucide="factory"></i>
```

Ícones essenciais para o domínio:
- `factory`, `clipboard-list`, `package`, `boxes`, `truck`, `building-2`
- `shield-check` (qualidade), `bar-chart-3`, `users`
- `play`, `pause`, `square` (estado de linha)
- `alert-triangle`, `alert-octagon`, `check-circle-2`
- `scissors` (corte), `needle` (costura — fallback `git-branch`), `box` (embalagem)

---

## ARQUITETURA DE INFORMAÇÃO

```
Dashboard           → KPIs do dia, linhas ao vivo, alertas, OPs ativas, materiais em risco
Operações
├─ Produção         → Linhas em tempo real, planejamento por turno, apontamentos
├─ Ordens (OPs)     → Lista, criar, priorizar, vincular lote
├─ Qualidade (QC)   → Inspeções, defeitos por modelo, liberação de lotes
└─ Expedição        → Lotes prontos, faturamento, transportadoras
Estoque
├─ Materiais        → Couro, sintético, palmilha, forro, fivelas, embalagem
├─ Acabados         → Pares por modelo/numeração/cor
└─ Fornecedores     → Cadastro, prazos, histórico
Insights
├─ Relatórios       → OEE, FPY, refugo, eficiência por linha
└─ Equipe           → Operadores, turnos, produtividade
```

---

## ÍNDICE DE ARQUIVOS

```
README.md                     ← este arquivo
SKILL.md                      ← skill do agente
colors_and_type.css           ← CSS vars HSL + tipografia
assets/
  logo-squad-shoes.jpg
preview/
  colors-primary.html
  colors-neutral.html
  colors-semantic.html
  type-scale.html
  type-specimens.html
  type-mono.html
  spacing.html
  radii-shadows.html
  btn-primary.html
  btn-ghost.html
  product-card.html           ← KPI / line cards (renomear conceito)
  badges-tags.html            ← status, etapas, prioridade, defeitos
  inputs.html                 ← cadastro de OP, numeração, cor
  size-selector.html          ← grade de numeração BR
ui_kits/
  web/
    index.html                ← Squad Shoes Factory OS
    Components.jsx            ← Sidebar, Topbar, KPI, DataTable, LineCard, etc.
    Dashboard.jsx
```
