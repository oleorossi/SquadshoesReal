// Squad Shoes Factory OS — Tela: Qualidade
// Inspeção, defeitos, lotes reprovados
function QualidadeScreen() {
  const [filter, setFilter] = useState('todos');

  const inspecoes = [
    { id: 'INSP-1247', op: 'OP-2847', model: 'Sandália Bianca — Caramelo',  lote: 'L-30/04-A', insp: 'Carla M.', amostras: 32, def: 1, status: 'aprovado',  hora: '14:22', cidade: 'Franca/SP' },
    { id: 'INSP-1246', op: 'OP-2845', model: 'Bota Cano Curto — Bordô',     lote: 'L-30/04-B', insp: 'Roberto F.', amostras: 30, def: 4, status: 'reprovado', hora: '13:48', cidade: 'Franca/SP' },
    { id: 'INSP-1245', op: 'OP-2846', model: 'Scarpin Renata — Preto',      lote: 'L-30/04-C', insp: 'Carla M.', amostras: 32, def: 0, status: 'aprovado',  hora: '12:15', cidade: 'Franca/SP' },
    { id: 'INSP-1244', op: 'OP-2843', model: 'Mule Aurora — Off-white',     lote: 'L-29/04-D', insp: 'Pedro L.', amostras: 60, def: 2, status: 'aprovado',  hora: '11:40', cidade: 'Franca/SP' },
    { id: 'INSP-1243', op: 'OP-2842', model: 'Tênis Joana — Verde militar', lote: 'L-29/04-E', insp: 'Pedro L.', amostras: 25, def: 5, status: 'pendente',  hora: '10:55', cidade: 'Franca/SP' },
    { id: 'INSP-1242', op: 'OP-2841', model: 'Anabela Verão — Caramelo',    lote: 'L-29/04-F', insp: 'Carla M.', amostras: 48, def: 1, status: 'aprovado',  hora: '09:30', cidade: 'Franca/SP' },
  ];

  const defeitos = [
    { tipo: 'Costura solta',         freq: 28, trend: '+4',  cor: 'hsl(0 78% 58%)' },
    { tipo: 'Cola excesso',          freq: 19, trend: '-2',  cor: 'hsl(38 92% 50%)' },
    { tipo: 'Numeração trocada',     freq: 12, trend: '+3',  cor: 'hsl(192 75% 21%)' },
    { tipo: 'Couro com mancha',      freq: 9,  trend: '-1',  cor: 'hsl(8 88% 67%)' },
    { tipo: 'Solado descolando',     freq: 7,  trend: '+1',  cor: 'hsl(269 60% 55%)' },
    { tipo: 'Forro deslocado',       freq: 4,  trend: '0',   cor: 'hsl(217 91% 55%)' },
  ];

  const filtered = filter === 'todos' ? inspecoes : inspecoes.filter(i => i.status === filter);

  return (
    <div style={{ padding: 24, display: 'flex', flexDirection: 'column', gap: 18 }} className="page-enter">
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12 }}>
        <KpiCard kind="featured" icon="shield-check" label="Aprovação 30 dias" value="96,4%" delta="+0,3pp" deltaLabel="vs mês ant."/>
        <KpiCard icon="search-check" label="Inspeções hoje"   value="18"  unit="lotes" delta="+3" deltaLabel="vs ontem"/>
        <KpiCard icon="x-circle"     label="Reprovados hoje"  value="2"   delta="+1"  deltaLabel="atenção"/>
        <KpiCard icon="alert-octagon" label="Pendentes"       value="5"   delta="—"   deltaLabel="aguardando"/>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 14 }}>
        <Panel title="Inspeções recentes" subtitle="Lotes inspecionados nas últimas 24h" padding={0}
          action={<>
            <SegmentedControl value={filter} onChange={setFilter} options={[
              { value: 'todos', label: 'Todos', count: inspecoes.length },
              { value: 'aprovado', label: 'Aprovados', count: 4 },
              { value: 'reprovado', label: 'Reprovados', count: 1 },
              { value: 'pendente', label: 'Pendentes', count: 1 },
            ]}/>
          </>}>
          <DataTable
            columns={[
              { key: 'id', label: 'Inspeção', render: r => <span style={{ fontFamily: T.mono, fontWeight: 700, fontSize: 12 }}>{r.id}</span> },
              { key: 'model', label: 'Modelo / OP', render: r => <div><div style={{ fontWeight: 600, fontSize: 12 }}>{r.model}</div><div style={{ fontFamily: T.mono, fontSize: 10, color: T.mutedFg }}>{r.op} · {r.lote}</div></div> },
              { key: 'amostras', label: 'Amostras', align: 'center', render: r => <span style={{ fontFamily: T.mono, fontSize: 12 }}>{r.amostras}</span> },
              { key: 'def', label: 'Defeitos', align: 'center', render: r => (
                <span style={{ fontFamily: T.mono, fontSize: 12, fontWeight: 700, color: r.def === 0 ? T.success : r.def <= 2 ? T.warning : T.destructive }}>{r.def}</span>
              )},
              { key: 'insp', label: 'Inspetor', render: r => <span style={{ fontSize: 12 }}>{r.insp}</span> },
              { key: 'hora', label: 'Hora', render: r => <span style={{ fontFamily: T.mono, fontSize: 11, color: T.mutedFg }}>{r.hora}</span> },
              { key: 'status', label: 'Status', render: r => <StatusPill status={r.status === 'aprovado' ? 'done' : r.status === 'reprovado' ? 'blocked' : 'queued'} label={r.status === 'aprovado' ? 'Aprovado' : r.status === 'reprovado' ? 'Reprovado' : 'Pendente'}/> },
            ]}
            rows={filtered}/>
        </Panel>

        <Panel title="Defeitos mais frequentes" subtitle="Últimos 30 dias">
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {defeitos.map(d => {
              const pct = (d.freq / 28) * 100;
              const up = d.trend.startsWith('+');
              return (
                <div key={d.tipo}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 }}>
                    <span style={{ fontFamily: T.sans, fontSize: 12, fontWeight: 600 }}>{d.tipo}</span>
                    <span style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                      <span style={{ fontFamily: T.mono, fontSize: 11, fontWeight: 700 }}>{d.freq}</span>
                      <span style={{ fontFamily: T.mono, fontSize: 10, fontWeight: 600, color: d.trend === '0' ? T.mutedFg : up ? T.destructive : T.success }}>{d.trend}</span>
                    </span>
                  </div>
                  <div style={{ height: 4, background: T.muted, borderRadius: 999 }}>
                    <div style={{ height: '100%', width: `${pct}%`, background: d.cor, borderRadius: 999, transition: 'width 600ms' }}/>
                  </div>
                </div>
              );
            })}
          </div>
        </Panel>
      </div>
    </div>
  );
}

// ── Tela: Expedição ──────────────────────────────────────
function ExpedicaoScreen() {
  const remessas = [
    { id: 'EXP-2026-0418', cliente: 'Lojas Carmen',     cnpj: '12.345.678/0001-90', destino: 'São Paulo/SP', pares: 480, peso: '142 kg', transp: 'TransExpress', status: 'enviado',     prev: '02/05/2026', nf: '058472' },
    { id: 'EXP-2026-0417', cliente: 'Atacado Central',  cnpj: '23.456.789/0001-01', destino: 'Belo Horizonte/MG', pares: 720, peso: '218 kg', transp: 'JadLog',      status: 'separado',    prev: '03/05/2026', nf: '058471' },
    { id: 'EXP-2026-0416', cliente: 'Rede Bella',       cnpj: '34.567.890/0001-12', destino: 'Curitiba/PR',  pares: 320, peso: '96 kg',  transp: 'Braspress',   status: 'em-rota',     prev: '01/05/2026', nf: '058470' },
    { id: 'EXP-2026-0415', cliente: 'Couro & Cia',      cnpj: '45.678.901/0001-23', destino: 'Rio de Janeiro/RJ', pares: 1200, peso: '358 kg', transp: 'TransExpress', status: 'entregue',  prev: '30/04/2026', nf: '058469' },
    { id: 'EXP-2026-0414', cliente: 'Palmilha Brasil',  cnpj: '56.789.012/0001-34', destino: 'Salvador/BA',  pares: 880, peso: '264 kg', transp: 'Mira',        status: 'separado',    prev: '04/05/2026', nf: '058468' },
    { id: 'EXP-2026-0413', cliente: 'Fast Shoes RJ',    cnpj: '67.890.123/0001-45', destino: 'Niterói/RJ',   pares: 240, peso: '72 kg',  transp: 'Braspress',   status: 'em-rota',     prev: '01/05/2026', nf: '058467' },
  ];

  return (
    <div style={{ padding: 24, display: 'flex', flexDirection: 'column', gap: 18 }} className="page-enter">
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12 }}>
        <KpiCard kind="featured" icon="truck" label="Expedidos hoje" value="3.840" unit="pares" delta="+12%" deltaLabel="vs ontem"/>
        <KpiCard icon="package-check" label="Pedidos separados" value="14" delta="+2" deltaLabel="hoje"/>
        <KpiCard icon="clock"         label="Em rota"           value="8"  delta="—"  deltaLabel="ativos"/>
        <KpiCard icon="check-circle-2" label="Entregues 7d"      value="42" delta="+18%" deltaLabel="vs sem. ant."/>
      </div>

      <Panel title="Remessas" subtitle={`${remessas.length} despachos · ordenados por previsão`} padding={0}
        action={<>
          <Btn variant="ghost" size="sm" icon="filter">Filtrar</Btn>
          <Btn variant="ghost" size="sm" icon="printer">Imprimir romaneio</Btn>
          <Btn variant="primary" size="sm" icon="plus">Nova remessa</Btn>
        </>}>
        <DataTable
          columns={[
            { key: 'id', label: 'Remessa', render: r => <div><div style={{ fontFamily: T.mono, fontWeight: 700, fontSize: 12 }}>{r.id}</div><div style={{ fontFamily: T.mono, fontSize: 10, color: T.mutedFg }}>NF {r.nf}</div></div> },
            { key: 'cliente', label: 'Cliente', render: r => <div><div style={{ fontWeight: 600, fontSize: 12 }}>{r.cliente}</div><div style={{ fontFamily: T.mono, fontSize: 10, color: T.mutedFg }}>{r.cnpj}</div></div> },
            { key: 'destino', label: 'Destino', render: r => <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5, fontSize: 12 }}><i data-lucide="map-pin" style={{ width: 11, height: 11, color: T.mutedFg }}></i>{r.destino}</span> },
            { key: 'qty', label: 'Volume', align: 'right', render: r => <div style={{ textAlign: 'right' }}><div style={{ fontFamily: T.mono, fontSize: 12, fontWeight: 600 }}>{r.pares.toLocaleString('pt-BR')} pares</div><div style={{ fontFamily: T.mono, fontSize: 10, color: T.mutedFg }}>{r.peso}</div></div> },
            { key: 'transp', label: 'Transportadora', render: r => <span style={{ fontSize: 12 }}>{r.transp}</span> },
            { key: 'prev', label: 'Previsão', render: r => <span style={{ fontFamily: T.mono, fontSize: 11, color: T.mutedFg }}>{r.prev}</span> },
            { key: 'status', label: 'Status', render: r => <ShippingPill status={r.status}/> },
          ]}
          rows={remessas}
          selectable/>
      </Panel>
    </div>
  );
}

function ShippingPill({ status }) {
  const map = {
    'separado':  { bg: T.warningSoft, fg: T.warningFg, dot: T.warning, lbl: 'Separado' },
    'em-rota':   { bg: T.infoSoft, fg: T.infoFg, dot: T.info, lbl: 'Em rota' },
    'enviado':   { bg: 'hsl(269 50% 96%)', fg: 'hsl(269 60% 38%)', dot: 'hsl(269 60% 55%)', lbl: 'Enviado' },
    'entregue':  { bg: T.successSoft, fg: T.successFg, dot: T.success, lbl: 'Entregue' },
  };
  const c = map[status] || map.separado;
  return (
    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6, padding: '3px 9px', borderRadius: 999, background: c.bg, color: c.fg, fontFamily: T.sans, fontSize: 11, fontWeight: 600 }}>
      <span style={{ width: 6, height: 6, borderRadius: '50%', background: c.dot }}/>
      {c.lbl}
    </span>
  );
}

function SegmentedControl({ value, onChange, options }) {
  return (
    <div style={{ display: 'inline-flex', background: T.mutedSoft, borderRadius: 8, padding: 3, border: `1px solid ${T.borderSoft}` }}>
      {options.map(o => {
        const active = o.value === value;
        return (
          <button key={o.value} onClick={() => onChange(o.value)}
            style={{
              padding: '5px 11px', borderRadius: 6, border: 'none', cursor: 'pointer',
              background: active ? 'white' : 'transparent', color: active ? T.foreground : T.mutedFg,
              fontFamily: T.sans, fontSize: 11, fontWeight: 600,
              boxShadow: active ? T.shadowCard : 'none',
              display: 'inline-flex', alignItems: 'center', gap: 5,
              transition: 'all 140ms',
            }}>
            {o.label}
            {o.count !== undefined && (
              <span style={{ fontFamily: T.mono, fontSize: 9, padding: '1px 5px', borderRadius: 4, background: active ? T.mutedSoft : T.muted, color: active ? T.foreground : T.mutedFg }}>{o.count}</span>
            )}
          </button>
        );
      })}
    </div>
  );
}

window.QualidadeScreen = QualidadeScreen;
window.ExpedicaoScreen = ExpedicaoScreen;
window.SegmentedControl = SegmentedControl;
