# Squad Shoes — Factory OS · Lovable Export

React + Vite. 4 telas funcionais (Painel, Produção, Ordens, Materiais), navegação, tweaks panel e tokens HSL alinhados ao design system do projeto (verde/creme/slate).

---

## Como importar no Lovable

### Opção 1 — colar arquivos manualmente (mais simples)
Crie um projeto novo no Lovable em modo React + Vite e cole estes arquivos nas posições indicadas:

\`\`\`
src/
├── App.jsx
├── main.jsx
├── index.css
└── components/
    ├── Components.jsx
    ├── TweaksPanel.jsx
    ├── Dashboard.jsx
    ├── ProducaoScreen.jsx
    ├── OrdensScreen.jsx
    └── MateriaisScreen.jsx
index.html
package.json
vite.config.js
\`\`\`

Peça ao Lovable: **"importa esses arquivos exatamente como estão e roda npm install"**.

### Opção 2 — clonar como projeto Vite local

\`\`\`bash
npm install
npm run dev
\`\`\`

---

## Stack

- **React 18** (hooks puros, sem libs UI extras)
- **Vite** (dev server + build)
- **Lucide icons** carregado via CDN no `index.html` (atributos `data-lucide="icon-name"`). Se preferir o pacote `lucide-react` para tree-shaking, troque os elementos `<i data-lucide="...">` por `<Icon />` componentes.
- **Plus Jakarta Sans** + **JetBrains Mono** via Google Fonts
- Tokens em CSS custom properties (`src/index.css`) **e** em objeto JS (`T` em `Components.jsx`) — escolha o que preferir consumir

---

## Estrutura

| Arquivo | Conteúdo |
|---|---|
| `App.jsx` | Roteamento por estado (`page`), composição da Sidebar + Topbar + tela ativa, panel de Tweaks |
| `components/Components.jsx` | Tokens `T`, Sidebar, Topbar, Btn, KpiCard, ProgressBar, DataTable, StatusPill, StageBadge, Panel, BarChart, StockBar, Timeline, etc. |
| `components/TweaksPanel.jsx` | Painel flutuante de tweaks + controles (Toggle, Radio, Slider, Color…) |
| `components/Dashboard.jsx` | Painel da fábrica — KPIs, linhas, alertas, gráfico, ordens recentes |
| `components/ProducaoScreen.jsx` | Cards de linha com etapas + heatmap turno × dia |
| `components/MateriaisScreen.jsx` | Categorias coloridas filtráveis + inventário detalhado |
| `components/OrdensScreen.jsx` | KPIs + kanban + tabela de OPs com prioridade |

---

## Próximos passos sugeridos

1. **Trocar dados mockados por fonte real** — todos os arrays de mock estão no topo de cada `*Screen.jsx`. Substituir por fetch/Supabase/API.
2. **Migrar para lucide-react** (opcional) — atualmente usa CDN com `createIcons()`; com React idiomático é melhor importar componentes.
3. **Conectar telas pendentes** (Qualidade, Expedição, Acabados, Fornecedores, Relatórios, Equipe) — placeholders prontos, basta replicar o padrão das 4 telas existentes.
4. **Persistir Tweaks** — hoje só vivem em memória; guardar em `localStorage` se quiser.

---

## Notas técnicas

- **Inline styles** em vez de Tailwind/styled-components para máxima portabilidade. Se quiser converter, os tokens HSL em `index.css` (`--primary`, `--accent`, etc.) já são compatíveis com a convenção shadcn/Tailwind.
- **Sem TypeScript** para reduzir fricção. Adicionar é trivial: renomear `.jsx` → `.tsx` e adicionar `tsconfig.json`.
- **Acessibilidade**: foco visível em botões, `title` em ícones colapsados, contraste WCAG AA em todas as combinações de cores. Adicionar `aria-label` nos botões só com ícone se for produção.
